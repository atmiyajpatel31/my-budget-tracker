import React from "react";
function TrackerTab() {
  return <div><h2>Monthly Tracker</h2><p>Summary view of expenses and income.</p></div>;
}
export default TrackerTab;
