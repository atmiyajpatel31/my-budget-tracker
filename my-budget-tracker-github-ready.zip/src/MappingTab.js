import React from "react";
function MappingTab() {
  return <div><h2>Mapping</h2><p>This is where you manage dropdown values (Years, Categories, etc.)</p></div>;
}
export default MappingTab;
