import React from "react";
function LogTab() {
  return <div><h2>Income/Expense Log</h2><p>Form to add entries will go here.</p></div>;
}
export default LogTab;
