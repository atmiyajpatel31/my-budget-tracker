My Budget Tracker - Deployment Instructions

1. Go to https://vercel.com and sign up or log in.
2. Download and unzip this project folder.
3. Open https://vercel.com/new and import your project.
4. Select 'Create React App' as the framework.
5. Click 'Deploy'. Your site will be live in minutes!

Login:
Username: atmiyajpatel
Password: budget
